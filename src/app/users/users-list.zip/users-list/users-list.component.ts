import {Component, ElementRef, HostListener, Input, OnInit} from '@angular/core';
import {FormControl} from '@angular/forms';
import {Observable} from 'rxjs';
import {map, startWith} from 'rxjs/operators';
import {DatabaseService} from '../../_services/DatabaseService';
import {ActivatedRoute, Router} from '@angular/router';
import {DialogComponent} from '../../dialog/dialog.component';
import { ConvertArray } from '../../_Pipes/ConvertArray.pipe';

@Component({
  selector: 'app-users-list',
  templateUrl: './users-list.component.html',
})
export class UsersListComponent implements OnInit {
  user: any = {};
  loading_list = false;

  sendingData = false;
  constructor(public db: DatabaseService, private route: ActivatedRoute,
              private router: Router,  public dialog: DialogComponent) {
  }
  ngOnInit() {
    this.get_data();
    this.usersList();
  }

  roles: any = [];
  get_data(){

    this.db.post_rqst(  {'franchise_id' : this.db.datauser.franchise_id }, 'franchises/roles')
    .subscribe((d:any) => { 
    this.roles=d.roles;
      console.log(this.roles);
      
    });
  }
  filter:any = {};
temp:any='';
d:any={};
users: any = [];
search: any = '';
filtering:any = false;

usersList(){

         
  this.loading_list = true;

    
    this.d.franchise_id = this.db.datauser.franchise_id || 0;
    this.d.location_id = this.db.datauser.location_id || 0;
    this.d.s = this.search;
    console.log(this.d);


    
    if( this.filter.access_level )this.filtering = true;

    
    console.log(this.filter);

    this.db.post_rqst(  {'filter' : this.filter,'user':  this.d , 'login': this.db.datauser }, 'franchises/usersList')
    .subscribe((d:any) => { 
     this.loading_list = false;
      this.users = d.users;
        
    console.log(this.users);
    
    },err => {  this.dialog.retry().then((result) => { this.usersList(); });   });
}




deleteUser(id){
  this.dialog.delete('User').then((result) => {
    if(result) {
         
  this.loading_list = true;

    this.db.post_rqst(  {'user':  id }, 'franchises/userDelete')
    .subscribe((data:any) => { 
  this.loading_list = false;
    this.usersList();
    },err => {  this.dialog.retry().then((result) => { this.deleteUser(id); });   });

    }
  });
}



}
